#!/bin/sh 
echo 1 > /sys/class/gpio/gpio17/value 
echo 0 > /sys/class/gpio/gpio27/value 
echo 1 > /sys/class/gpio/gpio22/value 
echo 1 > /sys/class/gpio/gpio5/value
echo 0 > /sys/class/gpio/gpio6/value 
echo 1 > /sys/class/gpio/gpio13/value